var nums= [2,3,69,71,34,17];
window.alert(nums);

var reverseNums= nums.reverse();
window.alert(reverseNums);

