var st= prompt('Enter a string');

rst= st.split('').reverse().join('');

window.alert(rst);