async function myfunction(){
    function GetVideo(){
        console.log("Got video");
    }
    function AddIntro(){
        return console.log("intro added");
    }
    function AddSummary(){
        return console.log("summary added");
    }
    GetVideo();
    await AddIntro();
    AddSummary();
}
myfunction();
console.log("checking the await function");