function acceptArray(...args){

    for(let i=0; i < args.length; i++){
        if(args[i] % 2 != 0){
            console.log(args[i]);
        }
        }
}

acceptArray(1,2,3,4,5,6,7,8,9,10);


