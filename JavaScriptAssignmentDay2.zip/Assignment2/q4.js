Login = (username='CT', password=' CT') =>{

    console.log(`Username: ${username}  Password:  ${password}`);
}

Login('rohan', 'rohanmittal');

