function arguement(...a){

    tot= a.length;
    console.log(`arguements passed are: ${a}`);
    console.log(`number of arguements passed are: ${tot}`);
}


arguement(1,2,3,4,6);
