sum = (a,b) =>{ 

   add= a + b;
   console.log(add);
}

sum(2,3);