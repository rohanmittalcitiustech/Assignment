max = (a,b,c) => {
    maxNumber= Math.max(a,b,c);
    console.log(`Max Number is ${maxNumber}`);
}

max(2,3,4);